// Register GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Initialize Lenis for Smooth Scrolling
const lenis = new Lenis({
    duration: 1.5, // Even slower, heavier scroll for luxury feel
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smooth: true
});

lenis.on('scroll', ScrollTrigger.update);

gsap.ticker.add((time) => {
  lenis.raf(time * 1000);
});
gsap.ticker.lagSmoothing(0);

// Hero Animations
const tl = gsap.timeline();

tl.from(".hero-bg img", {
    scale: 1.3,
    duration: 2.5,
    ease: "power3.out"
})
.from(".reveal-text", {
    y: 50,
    opacity: 0,
    duration: 1.5,
    ease: "power3.out"
}, "-=1.5")
.from(".hero-content p", {
    y: 20,
    opacity: 0,
    duration: 1,
    ease: "power2.out"
}, "-=1");

// Parallax Effects
gsap.to(".parallax-bg", {
    yPercent: 20,
    ease: "none",
    scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: true
    }
});

gsap.to(".parallax-img", {
    yPercent: -15,
    ease: "none",
    scrollTrigger: {
        trigger: ".showcase",
        start: "top bottom",
        end: "bottom top",
        scrub: true
    }
});

// Fade Ups
const fadeUps = document.querySelectorAll('.fade-up');
fadeUps.forEach(el => {
    gsap.from(el, {
        scrollTrigger: {
            trigger: el,
            start: "top 85%",
        },
        y: 40,
        opacity: 0,
        duration: 1.2,
        ease: "power3.out"
    });
});

// Counter Animations
const counters = document.querySelectorAll('.counter');
counters.forEach(counter => {
    const target = parseFloat(counter.getAttribute('data-target'));
    const isDecimal = target % 1 !== 0;

    ScrollTrigger.create({
        trigger: ".performance",
        start: "top 75%",
        onEnter: () => {
            gsap.to(counter, {
                innerHTML: target,
                duration: 2.5,
                ease: "power3.out",
                snap: { innerHTML: isDecimal ? 0.1 : 1 },
                onUpdate: function() {
                    if(isDecimal) {
                        counter.innerHTML = Number(this.targets()[0].innerHTML).toFixed(1);
                    }
                }
            });
        },
        once: true
    });
});

// Configurator Logic
const colorBtns = document.querySelectorAll('.color-btn');
const carLayers = document.querySelectorAll('.car-layer');

colorBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        // Update Buttons
        colorBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        // Update Car Images
        const selectedColor = btn.getAttribute('data-color');
        carLayers.forEach(layer => {
            if(layer.id === `layer-${selectedColor}`) {
                layer.classList.add('active');
            } else {
                layer.classList.remove('active');
            }
        });
    });
});
