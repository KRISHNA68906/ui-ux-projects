// Register GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Initialize Lenis for Smooth Scrolling
const lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)), 
    direction: 'vertical',
    gestureDirection: 'vertical',
    smooth: true,
    mouseMultiplier: 1,
    smoothTouch: false,
    touchMultiplier: 2,
    infinite: false,
});

// Link Lenis to GSAP ScrollTrigger
lenis.on('scroll', ScrollTrigger.update);

gsap.ticker.add((time) => {
  lenis.raf(time * 1000);
});

gsap.ticker.lagSmoothing(0);

// Custom Cursor
const cursor = document.querySelector('.cursor');
const links = document.querySelectorAll('a, .service-item, .project-card, .contact-btn');

document.addEventListener('mousemove', (e) => {
    gsap.to(cursor, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.1,
        ease: 'power2.out'
    });
});

links.forEach(link => {
    link.addEventListener('mouseenter', () => cursor.classList.add('active'));
    link.addEventListener('mouseleave', () => cursor.classList.remove('active'));
});

// Hero Animations
const tl = gsap.timeline();

tl.from(".line-reveal", {
    y: 100,
    opacity: 0,
    duration: 1.5,
    ease: "power4.out",
    stagger: 0.2,
    delay: 0.5
})
.from(".hero-right .image-wrapper", {
    clipPath: "inset(0 100% 0 0)",
    duration: 1.5,
    ease: "power4.inOut"
}, "-=1.2")
.from(".hero-right img", {
    scale: 1.2,
    duration: 1.5,
    ease: "power2.out"
}, "-=1.5");

// Parallax Image in Hero
gsap.to(".parallax-img", {
    yPercent: 20,
    ease: "none",
    scrollTrigger: {
        trigger: ".hero",
        start: "top top",
        end: "bottom top",
        scrub: true
    }
});

// Fade Up Animations
const fadeUps = document.querySelectorAll('.fade-up');

fadeUps.forEach(element => {
    gsap.from(element, {
        scrollTrigger: {
            trigger: element,
            start: "top 85%",
        },
        y: 50,
        opacity: 0,
        duration: 1,
        ease: "power3.out"
    });
});
