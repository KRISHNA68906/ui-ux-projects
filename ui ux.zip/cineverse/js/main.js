document.addEventListener('DOMContentLoaded', () => {

    // 1. Navbar Scroll Effect
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    }

    // 2. Search Overlay Toggle (Only needed if the overlay exists in HTML)
    const searchTrigger = document.getElementById('search-trigger');
    const closeSearchBtn = document.getElementById('close-search');
    const searchOverlay = document.getElementById('search-overlay');
    const searchInput = document.querySelector('.search-input');

    if (searchTrigger && searchOverlay && searchInput) {
        searchTrigger.addEventListener('click', (e) => {
            e.preventDefault();
            searchOverlay.classList.remove('hidden');
            setTimeout(() => searchInput.focus(), 100);
        });
    }

    if (closeSearchBtn && searchOverlay) {
        closeSearchBtn.addEventListener('click', () => {
            searchOverlay.classList.add('hidden');
        });
    }

    // Close search on escape
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchOverlay && !searchOverlay.classList.contains('hidden')) {
            searchOverlay.classList.add('hidden');
        }
    });

    // 3. Render Carousels
    const createMovieCard = (movie) => {
        return `
            <div class="movie-card" data-id="${movie.id}" onclick="openModal(${movie.id})">
                <img src="${movie.img}" alt="${movie.title}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=500&auto=format&fit=crop'">
                <div class="card-info">
                    <div class="card-title">${movie.title}</div>
                    <div class="card-meta">
                        <span class="match">${movie.match}</span>
                        <span class="age">${movie.age}</span>
                        <span class="duration">${movie.duration}</span>
                    </div>
                </div>
            </div>
        `;
    };

    const renderCarousel = (id, data) => {
        const container = document.getElementById(id);
        if (container && data) {
            container.innerHTML = data.map(createMovieCard).join('');
        }
    };

    if (window.moviesData) {
        renderCarousel('trending-carousel', window.moviesData.trending);
        renderCarousel('continue-carousel', window.moviesData.continue);
        renderCarousel('awards-carousel', window.moviesData.awards);
    } else {
        console.error("moviesData is not defined. Ensure data.js is loaded before main.js.");
    }

    // 4. Modal Logic
    const modal = document.getElementById('movie-modal');
    const closeBtn = document.querySelector('.close-modal-btn');
    const modalBackdrop = document.querySelector('.modal-backdrop');

    // Make openModal available globally so onclick="" works
    window.openModal = (id) => {
        if (!window.moviesData || !modal) return;

        // Find movie in all lists
        let movie = null;
        Object.values(window.moviesData).forEach(list => {
            const found = list.find(m => m.id === id);
            if (found) movie = found;
        });

        if (movie) {
            const modalImg = document.getElementById('modal-img');
            const modalTitle = document.getElementById('modal-title');
            
            if (modalImg) modalImg.src = movie.img;
            if (modalTitle) modalTitle.textContent = movie.title;
            
            // Populate modal recommendations
            const recsContainer = document.getElementById('modal-recs');
            if (recsContainer && window.moviesData.trending) {
                const recs = window.moviesData.trending.slice(0, 2);
                recsContainer.innerHTML = recs.map(createMovieCard).join('');
            }
            
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }
    };

    const closeModal = () => {
        if (modal) {
            modal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }
    };

    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (modalBackdrop) modalBackdrop.addEventListener('click', closeModal);
});
